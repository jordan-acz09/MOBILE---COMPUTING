import React, { useState } from 'react';
import { Text, View, TextInput, Button, TouchableOpacity, StyleSheet, Alert } from 'react-native';

export default function AddSong() {
  const [SongName, setSongName] = useState('');
  const [ArtistName, setArtistName] = useState('');

    // Annotation: This function will add the searched songs to the MyPlaylist
  const handleAddSong = () => {
     Alert.alert(
      "Information",
      "This button will add songs you have typed to your Myplaylist. For the final version, this updates your myPlaylist by adding the song to the bottom of your playlist."
    );

    console.log('Song added:', { name: SongName, artist: ArtistName});
    setSongName('');
    setArtistName('');
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Song Name"
        placeholderTextColor="gray"
        value={SongName}
        onChangeText={setSongName}
      />
      <TextInput
        style={styles.input}
        placeholder=" Artist/Artists Name "
        placeholderTextColor="gray"
        value={ArtistName}
        onChangeText={setArtistName}
      />
      <TouchableOpacity style={styles.button} onPress={handleAddSong}>
        <Text style={styles.buttonText}>Add To MyPlaylist</Text>
      </TouchableOpacity>
    </View>
    
  );
}


 {/* AddSong screen: Addsong screen is the part of the app that will allow users to add songs to their playlist, by typing in the name of the song and its artist.   */}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'black',
    padding: 20,
  },
  button: {
    backgroundColor: 'white',
    padding: 10,
    width: '80%',
    borderRadius: 10,
    alignItems: 'center',
  },
    buttonText: {
    color: 'black',
    fontSize: 16,
    alignItems: 'center'
  },
  input: {
    height: 40,
    borderColor: 'black',
    borderWidth: 5,
    marginBottom: 20,
    backgroundColor: 'white',
    paddingHorizontal: 10,
    borderRadius: 10,
    width: '80%',
    color: 'black',
  },
});