/* import React, { useState } from 'react';
import { SafeAreaView, Button, StyleSheet } from 'react-native';
import songs from '../App.js';
import SongCard from './songCards';

export default function MyPlaylist() {
  const [songList, setSongList] = useState([]);

  return (
    <SafeAreaView style={styles.container}>
      <Button title="Load Your Songs" onPress={() => setSongList(songs)} />
      {songList.length === 0 ? "" : songList.map((x) => (
        <SongCard
          key={x.id} // assuming each song has a unique id
          song={x}
        />
      ))}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
}); */

import { SafeAreaView, StyleSheet, Alert } from 'react-native';
import SongCard from './songCards';
import React from 'react';

export default function MyPlaylist() {
  const songs = [
    { song: 'Walk Me', artist: 'Harry Alexander' },
    { song: 'Hear Us', artist: 'Micah Oliver' },
    { song: 'Fear', artist: 'The Migos' },
    { song: 'Earthly Guys', artist: 'Justin Hall' },
    { song: 'You Know Me', artist: 'Mike Gotze' },
    { song: 'I Know', artist: 'King Julie' },
    { song: 'Talk To You', artist: 'Jordan Thunder' },
  ];

 {/* Myplaylist screen: This is one of the screens of JamApp that displays the musics the user listens to. In the final app, there will be a list of playlists, with their own list of songs instead and the user will be able to delete music from playlists */}

  {/* Foresight: In the future development of the app, user will be able to star or favourite a song, copying the song to another playlist of favourite songs. */}

  return (
    <SafeAreaView style={styles.container}>
      {songs.map((x, index) => (
        <SongCard key={index} song={x.song} artist={x.artist} />
      ))}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'purple',
    padding: 8,
    fontFamily: 'Calibri',
  },
});