import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const SongCard = ({ song, artist }) => (
  <View style={styles.card}>
    <Text style={styles.song}>{song}</Text>
    <Text style={styles.artist}>{artist}</Text>
  </View>
);

const styles = StyleSheet.create({
  card: {
    padding: 10,
    margin: 10,
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    shadowColor: 'black',
    shadowOpacity: 2,
    shadowRadius: 5,
  },
  song: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  artist: {
    fontSize: 16,
    color: '#666',
  },
});

export default SongCard;