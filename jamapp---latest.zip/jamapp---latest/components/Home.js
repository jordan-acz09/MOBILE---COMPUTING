import React from 'react';
import { Text, View } from 'react-native';
import styles from './style';

export default function Home() {
  return (
    <View style={styles.container}>
      <Text style={styles.bigText}>Welcome To JamApp</Text>
    </View>
  );
}


{/*  Home screen: Home Screen is just a welcome page for the JamApp user, in the final app there may be a consideration to have like a "playlist made for you" based on the genre that the user mostly listens to OR the songs that the user listens to the most*/}